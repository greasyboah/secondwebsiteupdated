Going to make a website displaying information about various lemur species. Probably will be highly inspired by other websites.
