        function toggleTheme() { 
            var theme = document.getElementsByTagName('link')[0]; 
	    var image = document.getElementsByClassName("icon")[0];
	    var image2 = document.getElementsByClassName("icon")[1];   
            if (theme.getAttribute('href') == '../css/styles.css') { 
                theme.setAttribute('href', '../css/styles2.css');
		image.src='../img/lemur2.png'; 
		image2.src='../img/lemur2.png';
            } 
	    else { 
                theme.setAttribute('href', '../css/styles.css'); 
		image.src='../img/lemur.png';
		image2.src='../img/lemur.png';
            } 
        } 
	function Active(){
		const act = document.getElementsByClassName("active")[0];
		const actObj = document.getElementsByClassName("activeObject")[0];
		act.classList.remove("active")
		actObj.classList.remove("activeObject");
		actObj.style.display = 'none';
}
	document.getElementById("indexbutton").onclick = function() {
		
    		const myObj = document.getElementById("Index");
		Active();
		myObj.classList.add("activeObject");
    		myObj.style.display = 'block';
		document.getElementById("indexbutton").classList.add("active");	    
        }

        document.getElementById("indributton").onclick = function() {
    		const myObj = document.getElementById("Indri");
		Active();
		myObj.classList.add("activeObject");
		myObj.style.display = 'inline';
		document.getElementById("indributton").classList.add("active");
        }
 
        document.getElementById("mousebutton").onclick = function() {
		const myObj = document.getElementById("MouseLemur");
		Active();
		myObj.classList.add("activeObject");
		myObj.style.display = 'block';
		document.getElementById("mousebutton").classList.add("active");

        }

        document.getElementById("bamboobutton").onclick = function() {
		const myObj = document.getElementById("Golden-Bamboo-Lemur");
		Active();
		myObj.classList.add("activeObject");
		myObj.style.display = 'block';
		document.getElementById("bamboobutton").classList.add("active");
        }

        document.getElementById("redbutton").onclick = function() {
		const myObj = document.getElementById("Red-Ruffed-Lemur");
		Active();
		myObj.classList.add("activeObject");
		myObj.style.display = 'block';
		document.getElementById("redbutton").classList.add("active");
		
        }